package lv4.operator

class SubtractOperator : AbstractOperator{

    override fun operate(x: Double, y: Double) = x - y
}