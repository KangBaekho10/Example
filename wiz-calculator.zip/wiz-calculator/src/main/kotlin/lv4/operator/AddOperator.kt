package lv4.operator

class AddOperator : AbstractOperator {

    override fun operate(x: Double, y: Double) = x + y
}