package lv4.operator

class MultiplyOperator : AbstractOperator {

    override fun operate(x: Double, y: Double) = x * y
}