package lv4.operator

interface AbstractOperator {

    fun operate(x: Double, y: Double): Double
}