package com.example.wizshop.api.jwtauth

data class RequestMember(
    val id: Long
)