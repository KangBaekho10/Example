rootProject.name = "wiz-event-mall"
