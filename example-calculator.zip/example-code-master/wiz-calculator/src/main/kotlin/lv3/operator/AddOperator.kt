package lv3.operator

class AddOperator {

    fun operate(x: Double, y: Double) = x + y
}