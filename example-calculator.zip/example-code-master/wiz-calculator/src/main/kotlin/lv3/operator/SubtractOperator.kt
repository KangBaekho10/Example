package lv3.operator

class SubtractOperator {

    fun operate(x: Double, y: Double) = x - y
}