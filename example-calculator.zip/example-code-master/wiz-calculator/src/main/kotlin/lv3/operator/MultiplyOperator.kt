package lv3.operator

class MultiplyOperator {

    fun operate(x: Double, y: Double) = x * y
}