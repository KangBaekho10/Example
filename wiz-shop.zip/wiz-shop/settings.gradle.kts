rootProject.name = "wiz-shop"
