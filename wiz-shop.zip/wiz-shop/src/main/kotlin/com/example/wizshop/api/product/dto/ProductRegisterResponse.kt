package com.example.wizshop.api.product.dto

data class ProductRegisterResponse(
    val productId: Long
)