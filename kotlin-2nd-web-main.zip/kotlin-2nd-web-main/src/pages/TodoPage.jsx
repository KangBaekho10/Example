import TodoContainer from "../components/TodoContainer";

const TodoPage = () => {
  return (
    <div>
      <TodoContainer />
    </div>
  );
};

export default TodoPage;
