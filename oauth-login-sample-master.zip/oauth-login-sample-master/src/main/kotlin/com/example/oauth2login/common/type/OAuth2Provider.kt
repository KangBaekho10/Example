package com.example.oauth2login.common.type

enum class OAuth2Provider {
    KAKAO, NAVER
}