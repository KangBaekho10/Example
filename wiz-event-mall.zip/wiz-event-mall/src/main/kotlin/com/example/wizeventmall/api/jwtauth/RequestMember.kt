package com.example.wizeventmall.api.jwtauth

data class RequestMember(
    val id: Long
)