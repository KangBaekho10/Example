package com.example.wizeventmall

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class WizEventMallApplicationTests {

	@Test
	fun contextLoads() {
	}

}
