package com.project.todoapp.domain.users.dtos

data class SignInArguments (
    val userName : String,
    val password : String
)