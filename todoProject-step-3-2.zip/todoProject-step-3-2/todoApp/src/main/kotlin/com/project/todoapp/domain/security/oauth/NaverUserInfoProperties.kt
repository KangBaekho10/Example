package com.project.todoapp.domain.security.oauth

data class NaverUserInfoProperties (
    val name : String
)
