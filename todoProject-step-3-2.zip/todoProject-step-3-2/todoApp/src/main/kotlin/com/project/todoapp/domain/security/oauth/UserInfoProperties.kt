package com.project.todoapp.domain.security.oauth

data class UserInfoProperties (
    val nickname : String
)
