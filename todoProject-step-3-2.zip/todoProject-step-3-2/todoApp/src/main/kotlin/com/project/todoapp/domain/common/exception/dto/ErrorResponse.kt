package com.project.todoapp.domain.common.exception.dto

data class ErrorResponse(val message: String?)
