package com.project.todoapp.domain.security.oauth

interface OAuthUserInfoResponse {

}
