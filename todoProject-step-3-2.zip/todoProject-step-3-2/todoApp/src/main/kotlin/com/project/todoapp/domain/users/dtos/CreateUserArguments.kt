package com.project.todoapp.domain.users.dtos

data class CreateUserArguments (
    val userName : String,
    val password : String
)