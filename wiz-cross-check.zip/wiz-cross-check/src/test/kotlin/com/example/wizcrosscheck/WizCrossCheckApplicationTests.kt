package com.example.wizcrosscheck

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class WizCrossCheckApplicationTests {

    @Test
    fun contextLoads() {
    }

}
