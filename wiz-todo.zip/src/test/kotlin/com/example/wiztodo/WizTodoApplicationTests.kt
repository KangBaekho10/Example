package com.example.wiztodo

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class WizTodoApplicationTests {

    @Test
    fun contextLoads() {
    }

}
