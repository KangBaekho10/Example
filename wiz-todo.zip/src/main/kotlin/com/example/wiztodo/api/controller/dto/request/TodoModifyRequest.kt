package com.example.wiztodo.api.controller.dto.request

data class TodoModifyRequest(
    val title: String,
    val contents: String
)