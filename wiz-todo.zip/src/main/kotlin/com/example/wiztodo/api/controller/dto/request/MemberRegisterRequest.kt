package com.example.wiztodo.api.controller.dto.request

data class MemberRegisterRequest(
    val email: String,
    val password: String
)