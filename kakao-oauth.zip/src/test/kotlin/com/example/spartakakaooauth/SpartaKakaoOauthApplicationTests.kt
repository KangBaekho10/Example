package com.example.spartakakaooauth

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class SpartaKakaoOauthApplicationTests {

    @Test
    fun contextLoads() {
    }

}
