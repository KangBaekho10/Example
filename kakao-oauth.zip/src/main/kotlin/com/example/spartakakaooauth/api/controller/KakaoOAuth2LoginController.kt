package com.example.spartakakaooauth.api.controller

import com.example.spartakakaooauth.api.service.KakaoOAuth2LoginService
import jakarta.servlet.http.HttpServletResponse
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController

@RestController
class KakaoOAuth2LoginController(
    private val kakaoOAuth2LoginService: KakaoOAuth2LoginService
) {

    // 1. 로그인 요청 왔을 때 로그인 페이지로 Redirect
    @GetMapping("/oauth2/login/kakao")
    fun redirectLoginPage(response: HttpServletResponse) {
        val loginPageUrl = kakaoOAuth2LoginService.generateLoginPageUrl()
        response.sendRedirect(loginPageUrl)
    }

    // 2. Authorization Code 받아서 로그인 완료처리해주는 (AccessToken 반환)
    @GetMapping("/oauth2/login/callback")
    fun callback(
        @RequestParam code: String
    ): ResponseEntity<String> {
        val accessToken = kakaoOAuth2LoginService.login(code)
        return ResponseEntity.ok(accessToken)
    }
}