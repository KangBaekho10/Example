package com.example.spartakakaooauth.api.service

import com.example.spartakakaooauth.client.KakaoOAuth2LoginClient
import com.example.spartakakaooauth.common.JwtHelper
import com.example.spartakakaooauth.domain.socialmember.service.SocialMemberDomainService
import org.springframework.stereotype.Service

@Service
class KakaoOAuth2LoginService(
    private val kakaoOAuth2LoginClient: KakaoOAuth2LoginClient,
    private val socialMemberDomainService: SocialMemberDomainService,
    private val jwtHelper: JwtHelper
) {
    fun generateLoginPageUrl(): String {
        return kakaoOAuth2LoginClient.generateLoginPageUrl()
    }

    fun login(code: String): String {
        return kakaoOAuth2LoginClient.getAccessToken(code)
            .let { kakaoOAuth2LoginClient.retrieveUserInfo(it) }
            .let { socialMemberDomainService.registerIfAbsent(it) }
            .let { jwtHelper.generateAccessToken(it.id!!) }
    }
}