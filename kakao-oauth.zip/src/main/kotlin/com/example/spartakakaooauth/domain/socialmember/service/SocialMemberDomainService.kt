package com.example.spartakakaooauth.domain.socialmember.service

import com.example.spartakakaooauth.client.dto.KakaoLoginUserInfoResponse
import com.example.spartakakaooauth.domain.socialmember.entity.SocialMember
import com.example.spartakakaooauth.domain.socialmember.repository.SocialMemberRepository
import org.springframework.stereotype.Service

@Service
class SocialMemberDomainService(
    private val socialMemberRepository: SocialMemberRepository
) {

    fun registerIfAbsent(userInfo: KakaoLoginUserInfoResponse): SocialMember {
        return socialMemberRepository.findByProviderNameAndProviderId("KAKAO", userInfo.id.toString())
            ?: socialMemberRepository.save(
                SocialMember(
                    providerName = "KAKAO",
                    providerId = userInfo.id.toString(),
                    nickname = userInfo.properties.nickname
                )
            )
    }
}