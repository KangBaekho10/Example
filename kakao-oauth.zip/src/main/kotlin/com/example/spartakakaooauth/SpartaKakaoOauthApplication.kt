package com.example.spartakakaooauth

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class SpartaKakaoOauthApplication

fun main(args: Array<String>) {
    runApplication<SpartaKakaoOauthApplication>(*args)
}
