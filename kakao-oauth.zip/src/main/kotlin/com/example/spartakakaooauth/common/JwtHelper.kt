package com.example.spartakakaooauth.common

import org.springframework.stereotype.Component

@Component
class JwtHelper {
    fun generateAccessToken(id: Long): String {
        return "sample_jwt_token"
    }
}