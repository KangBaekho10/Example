package com.project.todoapp.domain.todo.reply.dto

data class DeleteReplyArgument (
    val authorName : String,
    val password : String
)
