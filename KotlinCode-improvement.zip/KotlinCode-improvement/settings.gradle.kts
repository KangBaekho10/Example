rootProject.name = "KotlinCode"
