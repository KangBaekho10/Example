package com.sparta.kotlincode

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class KotlinCodeApplicationTests {

    @Test
    fun contextLoads() {
    }

}
