package com.sparta.kotlincode.chapter.chapter3

import org.springframework.stereotype.Service

@Service
class TestService {
    fun deleteLikeComment(id: Long) {
        TODO("Not yet implemented")
    }
}