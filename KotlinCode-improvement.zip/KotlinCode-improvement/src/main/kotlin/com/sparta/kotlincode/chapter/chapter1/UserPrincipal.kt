package com.sparta.kotlincode.chapter.chapter1

data class UserPrincipal(
    val id: Long,
    val email: String,
)