package com.sparta.kotlincode.chapter.chapter1

interface CommentService {
    fun deleteLikeComment(id: Long)

}
