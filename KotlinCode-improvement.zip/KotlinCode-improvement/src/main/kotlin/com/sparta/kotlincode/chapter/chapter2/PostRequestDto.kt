package com.sparta.kotlincode.chapter.chapter2

class PostRequestDto {

}
