package com.sparta.kotlincode.chapter.chapter1

import org.springframework.stereotype.Service

@Service
class CommentServiceImpl :CommentService {
    override fun deleteLikeComment(id: Long) {

    }
}