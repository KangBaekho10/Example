package com.sparta.kotlincode.chapter.chapter2

class PostResponseDto(post: Post) {

}
