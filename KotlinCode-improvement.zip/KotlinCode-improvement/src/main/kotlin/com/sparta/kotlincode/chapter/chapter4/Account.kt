package com.sparta.kotlincode.chapter.chapter4

data class Account(val username: String, val password: String, val email: String, val role: String)