package com.sparta.kotlincode.chapter.chapter1

data class ApiResponseDto(
    val message: String?,
    val value: Int,
)
